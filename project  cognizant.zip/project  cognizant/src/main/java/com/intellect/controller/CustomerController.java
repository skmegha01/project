package com.intellect.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CustomerController {

}
