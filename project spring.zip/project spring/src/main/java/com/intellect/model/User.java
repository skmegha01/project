package com.intellect.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	//@Column(name = "uname")
	private String userName;
	private String userPassword;
	private Integer userAge;
	private String userCity;
	private String userGender;
	private String userDept;
	private int userYear;
	//@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date UserDate;
	@Lob
	private byte[] userPic;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity, String userGender, String userDept, int userYear, Date UserDate) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userGender = userGender;
		this.userDept = userDept;
		this.userYear = userYear;
		this.UserDate = UserDate;
	}
	
	
	public User(Integer id, String userName, String userPassword, Integer userAge, String userCity,byte[] userPic, String userGender, String userDept, int userYear, Date UserDate) {
		super();
		this.id = id;
		this.userName = userName;
		this.userPassword = userPassword;
		this.userAge = userAge;
		this.userCity = userCity;
		this.userGender = userGender;
		this.userDept = userDept;
		this.userYear = userYear;
		this.UserDate = UserDate;
		this.userPic = userPic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	public Integer getUserAge() {
		return userAge;
	}
	public void setUserAge(Integer userAge) {
		this.userAge = userAge;
	}
	public String getUserCity() {
		return userCity;
	}
	public void setUserCity(String userCity) {
		this.userCity = userCity;
	}
	public String getUserGender() {
		return userGender;
	}
	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}
	public String getUserDept() {
		return userDept;
	}
	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}
	public int getUserYear() {
		return userYear;
	}
	public void setUserYear(int userYear) {
		this.userYear = userYear;
	}
	public Date getUserDate() {
		return UserDate;
	}
	public void setUserDate(Date UserDate) {
		this.UserDate = UserDate;
	}
		
	public byte[] getUserPic() {
		return userPic;
	}
	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}
	public String getUserPicture() {
		return Base64.encodeBase64String(userPic);
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", userName=" + userName + ", userPassword=" + userPassword + ", userAge=" + userAge
				+ ", userCity=" + userCity + ", userGender=" + userGender + ",userDept=" +userDept +", userYear=" + userYear +",UserDate=" + UserDate +"]";
	}
	
	
	
	
	
	
}
